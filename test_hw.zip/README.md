# ExpressLRS Officially Supported Devices

This repository is for adding approved ExpressLRS hardware to the Configurator. Once a target is accepted and merged, it will immediately be available in the Configurator ready for use.

All targets must go through an approval process before merging.  This requires a schematic review, hardware testing, and developer samples.  Manufacturers wishing to add targets should contact an ExpressLRS developer on discord https://discord.gg/expresslrs. It is recommended to do this very early in the design process.

Developed and maintained by **ExpressLRS LLC** and its passionate open source community, working together to advance reliable, high-performance radio control technology.
